import { NextResponse, type NextRequest } from "next/server";
import { z } from "zod";
import {
  projectCreateSchema,
  projectIdSchema,
  projectUpdateSchema,
} from "@/lib/validation/projects";

import { requireAdmin, applyCookies } from "../_utils";

class HttpError extends Error {
  status: number;
  code: string;
  details?: unknown;

  constructor(
    status: number,
    code: string,
    message: string,
    details?: unknown,
  ) {
    super(message);
    this.status = status;
    this.code = code;
    this.details = details;
  }
}

async function parseJson(req: Request): Promise<unknown> {
  try {
    return await req.json();
  } catch {
    throw new HttpError(400, "bad_json", "Invalid JSON body");
  }
}

function jsonError(err: unknown) {
  if (err instanceof HttpError) {
    return NextResponse.json(
      { error: { code: err.code, message: err.message, details: err.details } },
      { status: err.status },
    );
  }

  if (err instanceof z.ZodError) {
    return NextResponse.json(
      {
        error: {
          code: "validation_error",
          message: "Invalid input",
          details: err.flatten(),
        },
      },
      { status: 422 },
    );
  }

  return NextResponse.json(
    { error: { code: "internal_error", message: "Something went wrong" } },
    { status: 500 },
  );
}

export async function GET(req: NextRequest) {
  try {
    const auth = await requireAdmin(req);
    if (!auth.ok) return auth.response;

    const { supabase, cookiesToSet } = auth;

    const { data, error } = await supabase
      .from("projects")
      .select("*")
      .order("created_at", { ascending: false });

    if (error) throw new HttpError(500, "db_error", error.message, error);

    const res = NextResponse.json({ projects: data ?? [] });
    return applyCookies(res, cookiesToSet);
  } catch (err) {
    return jsonError(err);
  }
}

export async function POST(req: NextRequest) {
  try {
    const auth = await requireAdmin(req);
    if (!auth.ok) return auth.response;

    const { supabase, cookiesToSet } = auth;

    const body = await parseJson(req);
    const input = projectCreateSchema.parse(body);

    const { data, error } = await supabase
      .from("projects")
      .insert(input)
      .select("*")
      .single();

    if (error) throw new HttpError(500, "db_error", error.message, error);

    const res = NextResponse.json({ project: data }, { status: 201 });
    return applyCookies(res, cookiesToSet);
  } catch (err) {
    return jsonError(err);
  }
}

export async function PATCH(req: NextRequest) {
  try {
    const auth = await requireAdmin(req);
    if (!auth.ok) return auth.response;

    const { supabase, cookiesToSet } = auth;

    const body = await parseJson(req);

    // Validate ID (accepts number or numeric string), then validate the patch body
    const { id } = projectIdSchema.parse(body);

    // Split `id` from the rest, then validate allowed update fields
    const rest = { ...(body as Record<string, unknown>) };

    const patch = projectUpdateSchema.parse(rest);

    const { data, error } = await supabase
      .from("projects")
      .update(patch)
      .eq("id", id)
      .select("*")
      .single();

    if (error) throw new HttpError(500, "db_error", error.message, error);
    if (!data) throw new HttpError(404, "not_found", "Project not found");

    const res = NextResponse.json({ project: data });
    return applyCookies(res, cookiesToSet);
  } catch (err) {
    return jsonError(err);
  }
}

export async function DELETE(req: NextRequest) {
  try {
    const auth = await requireAdmin(req);
    if (!auth.ok) return auth.response;

    const { supabase, cookiesToSet } = auth;

    const url = new URL(req.url);
    const idParam = url.searchParams.get("id");
    if (!idParam) {
      throw new HttpError(
        400,
        "missing_id",
        "Missing required query param: id",
      );
    }

    const id = projectIdSchema.parse({ id: idParam }).id;

    const { error } = await supabase.from("projects").delete().eq("id", id);
    if (error) throw new HttpError(500, "db_error", error.message, error);

    const res = NextResponse.json({ ok: true });
    return applyCookies(res, cookiesToSet);
  } catch (err) {
    return jsonError(err);
  }
}
